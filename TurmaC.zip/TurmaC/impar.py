num = int(input("digite um numero :"))

for i in range(1,num+1):
    if i%2!=0:
      print(i)
