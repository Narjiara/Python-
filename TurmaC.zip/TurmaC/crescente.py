n1 = float(input("Digite seu primeiro numero: "));
n2 = float(input("Digite o segundo numero: "));

if  n1 != n2:

    if n1 > n2:
        print(n2,n1);
    else:
        print(n1,n2)

else:
    print("Numeros iguais");

