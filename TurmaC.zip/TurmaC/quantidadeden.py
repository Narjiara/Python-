nome = input("digite o seu nome:")
cont = 0
for c in nome:
    cont = cont+1
print(cont)

