nome = input("digite o seu nome:")
i=1
for c in nome:
    print(i,c)
    i=i+1
