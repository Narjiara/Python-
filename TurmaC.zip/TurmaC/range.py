num = int(input("digite um numero:"))
tabuada = 1

for x in range(1,11):

    print(num,"x",x,"=",num*x)
    