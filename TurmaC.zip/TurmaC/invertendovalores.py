A = 5
B = 10

print("O valor de A:" , A,"\n O valor de B:" , B)

C = A
A = B
B = C
print("Invertendo os valores")
print("O valor de A:" , A,"\n O valor de B:" , B)